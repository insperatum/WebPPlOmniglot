'use strict';
var Canvas = require('canvas');
var fs = require('fs');

var ad;
var Tensor;
var nn;
module.exports = {init: function(ad_, Tensor_, nn_) {
  ad = ad_;
  Tensor = Tensor_;
  nn = nn_;
  
  var fill = ad.newFunction({
    OutputType: Tensor,
    name: "create",
    forward: function(w, h, val) {
      var t = ad.lift(new Tensor([1, w, h]).fill(ad.value(val)));
      var lineLength = ad.lift(0)
      return {t:t, lineLength:lineLength, overlap:0}
    },
    backward: function(w, h, val) {
      val.dx = this.t.dx.sumreduce()
    },
    getParents: function(w, h, val) {
      return ad.isLifted(val) ? [val] : []
    }
  });
      
  var drawLine = function(adcanvas, p1, p2, linewidth) {
    'use ad';
    
    var w = ad.value(adcanvas.t).dims[1]
    var h = ad.value(adcanvas.t).dims[2]
    
    // console.log("Drawing line from (", ad.value(p1.x), ", ", ad.value(p1.y), ") to (", ad.value(p2.x), ", ", ad.value(p2.y), ")")
    // var xmin = Math.max(0, Math.min(ad.value(x1), ad.value(x2))-Math.ceil(ad.value(linewidth)) + 1)
    // var xmax = Math.min(w-1, Math.max(ad.value(x1), ad.value(x2))+Math.ceil(ad.value(linewidth)) - 1)
    // var ymin = Math.max(0, Math.min(ad.value(y1), ad.value(y2))-Math.ceil(ad.value(linewidth)) + 1)
    // var ymax = Math.min(h-1, Math.max(ad.value(y1), ad.value(y2))+Math.ceil(ad.value(linewidth)) - 1)

    var pixels = []
    var overlap = adcanvas.overlap
    // TODO: we can do much better than restricting to this square
    for(var y = 0; y < h; y++) {
      for(var x = 0; x < w; x++) {
        var pixel = drawPixelIntensity(ad.tensorEntry(adcanvas.t, x + w*y), x, y, p1.x, p1.y, p2.x, p2.y, linewidth);
        pixels.push(pixel.val)
        overlap += pixel.overlap
      }
    }
    var xdiff = p1.x-p2.x
    var ydiff = p1.y-p2.y
    var len = Math.sqrt(xdiff*xdiff + ydiff*ydiff)
    var lineLength = adcanvas.lineLength + len
    
    var vector = ad.scalarsToTensor(pixels)
    var output = ad.tensor.reshape(vector, [1, w, h])
    return {t:output, lineLength:lineLength, overlap:overlap};
  }
  
  var closestDistance = function(x, y, x1, y1, x2, y2) {
    'use ad';
    
    var xdiff = x2-x1
    var ydiff = y2-y1
    var len = Math.sqrt(xdiff * xdiff + ydiff * ydiff)
    var projection = ((x-x1)*xdiff + (y-y1)*ydiff) / len
    
    if(projection<0) {
      return Math.sqrt(Math.pow(x-x1, 2) + Math.pow(y-y1, 2))
    } else if(projection > len) {
      return Math.sqrt(Math.pow(x-x2, 2) + Math.pow(y-y2, 2))
    } else {
      return Math.abs(ydiff*x - xdiff*y + x2*y1 - y2*x1) / len
    }
  }
  
  var drawPixelIntensity = function(currentvalue, x, y, x1, y1, x2, y2, linewidth) {
    'use ad';
    var lower = (linewidth-1)/2
    var d = closestDistance(x, y, x1, y1, x2, y2);
    var overlay;
    if(d < lower) {
      overlay = 1
    } else if(d < lower+1) {
      overlay = lower+1-d
    } else {
      overlay = 0
    }
    // return Math.min(1, currentvalue + overlay)
    return {val:1 - (1-currentvalue)*(1-overlay), overlap:currentvalue*overlay}
  }
  
  var saveImage = function(adcanvas, filename, colour) {
    if(colour === undefined) {colour = [255, 255, 255];}
    
    var tens = ad.value(adcanvas.t)
    var w = tens.dims[1]
    var h = tens.dims[2]
    
    var canvas = new Canvas(w, h);
    var ctx=canvas.getContext("2d");
    var imageData = ctx.createImageData(w, h)
    for(var x=0; x<w; x++) {
      for(var y=0; y<h; y++) {
        imageData.data[4*(y + x*h)+0] = 255*tens.get([0, x, y])*colour[0];
        imageData.data[4*(y + x*h)+1] = 255*tens.get([0, x, y])*colour[1];
        imageData.data[4*(y + x*h)+2] = 255*tens.get([0, x, y])*colour[2];
        imageData.data[4*(y + x*h)+3] = 255;
      }
    }
    ctx.putImageData( imageData, 0, 0 );
    fs.writeFileSync(filename, canvas.toBuffer());
  }
  
  var saveOverlay = function(adcanvas1, adcanvas2, filename, colour1, colour2) {
    if(colour1 === undefined) {colour = [255, 255, 255];}
    if(colour2 === undefined) {colour = [255, 255, 255];}
    
    var tens1 = ad.value(adcanvas1.t)
    var tens2 = ad.value(adcanvas2.t)
    var w = tens1.dims[1]
    var h = tens1.dims[2]
    
    var canvas = new Canvas(w, h);
    var ctx=canvas.getContext("2d");
    var imageData = ctx.createImageData(w, h)
    for(var x=0; x<w; x++) {
      for(var y=0; y<h; y++) {
        imageData.data[4*(y + x*h)+0] = 255*(1-(1-tens1.get([0, x, y])*colour1[0])*(1-tens2.get([0, x, y])*colour2[0]));
        imageData.data[4*(y + x*h)+1] = 255*(1-(1-tens1.get([0, x, y])*colour1[1])*(1-tens2.get([0, x, y])*colour2[1]));
        imageData.data[4*(y + x*h)+2] = 255*(1-(1-tens1.get([0, x, y])*colour1[2])*(1-tens2.get([0, x, y])*colour2[2]));
        imageData.data[4*(y + x*h)+3] = 255;
      }
    }
    ctx.putImageData( imageData, 0, 0 );
    fs.writeFileSync(filename, canvas.toBuffer());
  }

  var gaussianKernel = function(sd) {
    var w = 2*sd + 1;
    var kernel = new Tensor([1, w, w])
    var variance = sd*sd
    for(var x=0; x<w; x++) {
      for(var y=0; y<w; y++) {
        var xdiff = x-(w-1)/2
        var ydiff = y-(w-1)/2
        kernel.data[x + y*w] = Math.exp( -(xdiff*xdiff + ydiff*ydiff) / variance)
      }
    }
    kernel = ad.tensor.div(kernel, kernel.sumreduce())
    return kernel
  }
  
  var powKernel = function(w, pow) {
    var kernel = new Tensor([1, w, w])
    for(var x=0; x<w; x++) {
      for(var y=0; y<w; y++) {
        var xdiff = (x-(w-1)/2)/w
        var ydiff = (y-(w-1)/2)/w
        kernel.data[x + y*w] = Math.pow( 1+ xdiff*xdiff + ydiff*ydiff, pow/2)
      }
    }
    kernel = ad.tensor.div(kernel, kernel.sumreduce())
    return kernel
  }
  
  var convolve = function(adcanvas, filter) {
    var tens = ad.value(adcanvas.t)
    var w = tens.dims[1]
    var h = tens.dims[2]
    var fw = filter.dims[1]
    var fh = filter.dims[2]
    
    var t = nn.convolve(adcanvas.t, filter.clone().reshape([1, 1, fw, fh]), new Tensor([1, w, h]), 1, 1, (fw-1)/2, (fh-1)/2)
    return {t:t, lineLength:adcanvas.lineLength, overlap:adcanvas.overlap}
  }
  
  var drawStroke = function(adcanvas, startPoint, controlPoints, linewidth) {
    'use ad';
    var out = adcanvas;
    // var ts = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1]
    var ts = [0, 0.2, 0.4, 0.6, 0.8, 1];
    var coords = [];
    // console.log("Old coords:")
    for(var i=0; i<ts.length; i++) {
      coords.push(interpolate(ts[i], 3, [{x:0, y:0}].concat(controlPoints)))
      // console.log(ad.value(coords[i].x), ad.value(coords[i].y))
    }
    
    // console.log("Start point: (", ad.value(coords[0].x), ", ", ad.value(coords[0].y), ")")
    var delX = startPoint.x - coords[0].x
    var delY = startPoint.y - coords[0].y;
    // console.log("\nNew coords:")
    for(var i=0; i<ts.length; i++) {
      coords[i].x = 32 * (coords[i].x + delX);
      coords[i].y = 32 * (coords[i].y + delY);
      // console.log(ad.value(coords[i].x), ad.value(coords[i].y))
    }

    
    for(var i=0; i<ts.length-1; i++) {
      // console.log("Drawing from ", coords[i][0], coords[i][1], "to", coords[i+1][0], coords[i+1][1])
      out = drawLine(out, coords[i], coords[i+1], linewidth)
    }
    
    return out
  }


  var spatialTransformer = function(adcanvas, w, h, transformation) {
    'use ad';
    // console.log(ad.value(adcanvas.t))
    // console.log("?")
    var oldw = ad.value(adcanvas.t).dims[1]
    var oldh = ad.value(adcanvas.t).dims[2]
  // x* = a*x + b
  // x* = w * (a*x/oldw + b)
  // x* = (a*w/oldw) x + w*b
    var W = {ax: transformation.ax * w / oldw, bx: transformation.bx * w,
             ay: transformation.ay * h / oldh, by: transformation.by * h};
    
    var pixels = []
    var overlap = adcanvas.overlap
    for(var y = 0; y < h; y++) {
      for(var x = 0; x < w; x++) {
        var pre = {x:(x-W.bx)/W.ax, y:(y-W.by)/W.ay}
        var lower = {x:Math.floor(pre.x), y:Math.floor(pre.y)}
        var upper = {x:lower.x+1, y:lower.y+1}
        var rem = {x:pre.x-lower.x, y:pre.x-lower.x}
        
        var lx = ad.value(lower.x)
        var ux = ad.value(upper.x)
        var ly = ad.value(lower.y)
        var uy = ad.value(upper.y)
        var v00 =0, v01=0, v10=0, v11=0
        if (lx>=0 && lx<oldw && ly>=0 && ly<oldh) { v00 = ad.tensorEntry(adcanvas.t, lx + oldw * ly) }
        if (lx>=0 && lx<oldw && uy>=0 && uy<oldh) { v01 = ad.tensorEntry(adcanvas.t, lx + oldw * uy) }
        if (ux>=0 && ux<oldw && ly>=0 && ly<oldh) { v10 = ad.tensorEntry(adcanvas.t, ux + oldw * ly) }
        if (ux>=0 && ux<oldw && uy>=0 && uy<oldh) { v11 = ad.tensorEntry(adcanvas.t, ux + oldw * uy) }

        var val = v00 * (1-rem.x) * (1-rem.y) + v01 * (1-rem.x) * rem.y + v10 * (1-rem.x) * rem.y + v11 * rem.x * rem.y
        pixels.push(val)
      }
    }
    
    var vector = ad.scalarsToTensor(pixels)
    var output = ad.tensor.reshape(vector, [1, w, h])
    return {t:output};
  }
  
  // var spatialTransformer = function(adcanvas)
  
    // var draw = ad.newFunction({
  //   OutputType: Tensor,
  //   name: "draw",
  //   forward: function(adcanvas, template, ox, oy) {
  //     var adcanvas = ad.value(adcanvas)
  //     var w = tens.dims[1]
  //     var h = tens.dims[2]

  //     var template = ad.value(template)
  //     var tw = tens.dims[1]
  //     var th = tens.dims[2]
      
  //     var output = adcanvas.clone()
      
  //     var fx = Math.floor(ox)
  //     var fy = Math.floor(oy)
  //     var ux = ox - fx
  //     var uy = oy - fy
      
  //     for(var x=Math.max(fx,0); x<Math.min(w, fx+tw+1); x++) {
  //       for(var y=Math.max(fy,0); y<Math.min(h, fy+th+1); y++) {
  //         var tx = x-fx//
  //         var ty = t-fy
  //         var i = tx + w*ty;
          
  //         f00 = tx>0 && ty>0 ? template.data[i] : 0;
  //         f01 = tx>0 && ty<w ? template.data[i + w];
  //         f10 = template.data[i + 1];
  //         f11 = template.data[i + w + 1];
          
          
  //       }
  //     }
  //     var t = new Tensor([1, w, h]).fill(ad.value(val));
  //     return output;
  //   },
  //   backward: function(w, h, val) {
  //     // val.dx = this.x.sumreduce()
  //   },
  //   getParents: ad.naryGetParents
  // });
  
  // var drawLine = ad.newFunction({
  //   OutputType: Tensor,
  //   name: "drawLine",
  //   forward: function(adcanvas, x1, y1, x2, y2, linewidth) {
  //     // console.log(typeof adcanvas)
  //     // linewidth = (linewidth===undefined) ? 1 : linewidth
  //     var tens = ad.value(adcanvas)
  //     var w = tens.dims[1]
  //     var h = tens.dims[2]
      
  //     var cloned = {adcanvas: ad.clone(adcanvas), x1:ad.clone(x1), y1:ad.clone(y1), x2:ad.clone(x2), y2:ad.clone(y2), linewidth:ad.clone(linewidth)}
  //     var output = ad.lift(new Tensor(tens.dims))
  //     output.
  //     // var xmin = Math.max(0, Math.min(ad.value(x1), ad.value(x2))-Math.ceil(ad.value(linewidth)) + 1)
  //     // var xmax = Math.min(w-1, Math.max(ad.value(x1), ad.value(x2))+Math.ceil(ad.value(linewidth)) - 1)
  //     // var ymin = Math.max(0, Math.min(ad.value(y1), ad.value(y2))-Math.ceil(ad.value(linewidth)) + 1)
  //     // var ymax = Math.min(h-1, Math.max(ad.value(y1), ad.value(y2))+Math.ceil(ad.value(linewidth)) - 1)
  //     var xmin=0;
  //     var ymin=0;
  //     var xmax=w-1;
  //     var ymax=h-1;
      
  //     var pixels =
  //     // TODO: we can do much better than restricting to this square
  //     for(var x = xmin; x < xmax + 1; x++) {
  //       for(var y = ymin; y < ymax; y++) {
          
  //         var val = drawPixelIntensity(ad.tensorEntry(cloned.adcanvas, x + w*y), x, y, cloned.x1, cloned.y1, cloned.x2, cloned.y2, cloned.linewidth);
  //         output.x.data[x + w*y] = ad.value(val)
  //         if(ad.isLifted(val)) {
  //           output.foofty[x + w*y] = val
  //         }
  //       }
  //     }
      
  //     output.cloned = cloned
  //     return output;
  //   },
  //   backward: function(adcanvas, x1, y1, x2, y2, linewidth) {
  //     console.log("backprop!")
  //     // console.log(this)
  //     for(var i in this.x.foofty) {
  //       ad.scalar.mul(this.x.foofty[i], this.dx.data[i]).backprop()
  //     }
  //   },
  //   // getParents: function(adcanvas, x1, y1, x2, y2, linewidth) {
  //   //   return [adcanvas, x1]
  //   //   // console.log("getParents")
  //   //   // console.log(a,b,c,d,e,f)
  //   //   // console.log(this)
  //   //   // var p = []
  //   //   // for(var i in this.x.foofty) {
  //   //   //   p.push(ad.scalar.mul(this.x.foofty[i], this.dx.data[i]).backprop())
  //   //   // }
  //   //   // return p;
  //   //   return []
  //   // }
  //   getParents: ad.naryGetParents
  // });
  
  var BmpDecoder = function(buffer) {
    this.pos = 0;
    this.buffer = buffer;
    this.flag = this.buffer.toString("utf-8", 0, this.pos += 2);
    if (this.flag != "BM") throw new Error("Invalid BMP File");
    this.parseHeader();
    this.parseData();
  }
  
  BmpDecoder.prototype.parseHeader = function() {
    this.fileSize = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.reserved = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.offset = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.headerSize = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.width = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.height = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.planes = this.buffer.readUInt16LE(this.pos);
    this.pos += 2;
    this.bitPP = this.buffer.readUInt16LE(this.pos);
    this.pos += 2;
    this.compress = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.rawSize = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.hr = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.vr = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.colors = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
    this.importantColors = this.buffer.readUInt32LE(this.pos);
    this.pos += 4;
  };
  
  BmpDecoder.prototype.parseData = function() { // for 24 bit
    this.pos = this.offset;
  
    this.data = new Tensor([1, this.width, this.height]);
  
  
    for (var x = 0; x < this.width; x++) {
      for (var y = this.height - 1; y >= 0; y--) {
        var value = this.buffer.readUInt8(this.pos);
        this.data.set([0, x, y], value/255);
        this.pos+=3;
      }
      //skip extra bytes
      this.pos += (this.width % 4);
    }
  };
  
  BmpDecoder.prototype.getData = function() {
    return this.data;
  };


  var loadImage = function(path) {
    var bmpBuffer = fs.readFileSync(path);
    var decoder = new BmpDecoder(bmpBuffer);
    return {t: decoder.getData()};
  };

  var countval = -1;
  var counter = function(inc) {
    if(inc) {countval++}
    return countval;
  }
  
  var error = function() {
    throw new Error("error!");
  }
  
  var getDate = function() {
    return new Date().toLocaleTimeString();
  }
  
  var omniglotFiles = fs.readdirSync("32x32/");
  
  var randomOmniglot = function() {
    // var i = Math.floor(Math.random()*omniglotFiles.length)
    var idxs = [100,200,300,400,500]
    var i = Math.floor(Math.random()*5)
    var name = omniglotFiles[idxs[i]]
    // var name = "9099.bmp"
    var path = "32x32/" + name
    // console.log("Loading: " + path);
    var obs = loadImage(path);
    return {name:name, obs:obs}
  }
  
  return {fill, drawLine, saveImage, saveOverlay, gaussianKernel, convolve, drawStroke, powKernel, loadImage, counter, error, getDate, spatialTransformer, randomOmniglot};
}}











function interpolate(t, order, points, knots, weights, result) {
  'use ad';
  
  var i,j,s,l;              // function-scoped iteration variables
  var n = points.length;    // points count
  var d = 2; // point dimensionality

  if(order < 2) throw new Error('order must be at least 2 (linear)');
  if(order > n) throw new Error('order must be less than point count');

  if(!weights) {
    // build weight vector of length [n]
    weights = [];
    for(i=0; i<n; i++) {
      weights[i] = 1;
    }
  }

  if(!knots) {
    // build knot vector of length [n + order]
    var knots = [];
    for(i=0; i<n+order; i++) {
      knots[i] = i;
    }
  } else {
    if(knots.length !== n+order) throw new Error('bad knot vector length');
  }

  var domain = [
    order-1,
    knots.length-1 - (order-1)
  ];

  // remap t to the domain where the spline is defined
  var low  = knots[domain[0]];
  var high = knots[domain[1]];
  t = t * (high - low) + low;

  if(t < low || t > high) throw new Error('out of bounds');

  // find s (the spline segment) for the [t] value provided
  for(s=domain[0]; s<domain[1]; s++) {
    if(t >= knots[s] && t <= knots[s+1]) {
      break;
    }
  }

  // convert points to homogeneous coordinates
  var v = [];
  for(i=0; i<n; i++) {
    v[i] = {x:points[i].x * weights[i],
            y:points[i].y * weights[i],
            weight:weights[i]}
  }

  // l (level) goes from 1 to the curve order
  var alpha;
  for(l=1; l<=order; l++) {
    // build level l of the pyramid
    for(i=s; i>s-order+l; i--) {
      alpha = (t - knots[i]) / (knots[i+order-l] - knots[i]);

      // interpolate each component
      // for(j=0; j<d+1; j++) {
        v[i].x = (1 - alpha) * v[i-1].x + alpha * v[i].x;
        v[i].y = (1 - alpha) * v[i-1].y + alpha * v[i].y;
        v[i].weight = (1 - alpha) * v[i-1].weight + alpha * v[i].weight;
      // }
    }
  }

  // convert back to cartesian and return
  // var result = result || [];
  // for(i=0; i<d; i++) {
    result = {x: v[s].x / v[s].weight, y: v[s].y / v[s].weight};
  // }

  // console.log("i:", result)
  return result
}
